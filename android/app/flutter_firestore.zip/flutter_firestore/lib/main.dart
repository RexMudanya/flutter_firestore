import 'package:flutter/material.dart';
import 'Home.dart';

void main(){
  runApp(new MaterialApp(
    home: Home(),
    debugShowCheckedModeBanner: false,
  ));
}
